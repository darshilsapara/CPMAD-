import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: NewsDashboardScreen(),
  ));
}

class NewsDashboardScreen extends StatefulWidget {
  const NewsDashboardScreen({super.key});

  @override
  State<NewsDashboardScreen> createState() => _NewsDashboardScreenState();
}

class _NewsDashboardScreenState extends State<NewsDashboardScreen> {
  // Categories list for GridView
  final List<Map<String, dynamic>> categories = [
    {'title': 'Tech', 'icon': Icons.computer, 'color': Colors.blue},
    {'title': 'Business', 'icon': Icons.trending_up, 'color': Colors.green},
    {'title': 'Sports', 'icon': Icons.sports_soccer, 'color': Colors.orange},
    {'title': 'World', 'icon': Icons.public, 'color': Colors.purple},
  ];

  // News list for ListView / SliverList
  final List<Map<String, String>> newsArticles = [
    {
      'title': 'AI Breakthrough in 2026',
      'subtitle': 'New reasoning models reshape everyday mobile apps.',
      'time': '10 min ago',
    },
    {
      'title': 'Global Markets Hit Record Highs',
      'subtitle': 'Tech stocks surge amid strong quarterly earnings.',
      'time': '1 hour ago',
    },
    {
      'title': 'Championship Finals Announced',
      'subtitle': 'Teams gear up for an unforgettable showdown.',
      'time': '3 hours ago',
    },
    {
      'title': 'Clean Energy Expansion',
      'subtitle': 'Solar and wind investments set historic record.',
      'time': '5 hours ago',
    },
  ];

  // Pull-to-refresh handler
  Future<void> _refreshData() async {
    await Future.delayed(const Duration(seconds: 1));
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Requirement 8: Pull-to-refresh behavior
      body: RefreshIndicator(
        onRefresh: _refreshData,
        // Requirement 5: CustomScrollView with always scrollable physics for smooth pull-to-refresh
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            // Requirement 4 & 7: Collapsing SliverAppBar
            SliverAppBar(
              expandedHeight: 180.0,
              pinned: true,
              backgroundColor: Colors.indigo,
              flexibleSpace: FlexibleSpaceBar(
                title: const Text(
                  'Daily Pulse News',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.indigo, Colors.indigoAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: const Center(
                    child: Icon(Icons.newspaper, size: 70, color: Colors.white24),
                  ),
                ),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.notifications_none),
                  onPressed: () {},
                ),
              ],
            ),

            // Requirement 3: Featured Article section using Stack
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Featured Story',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Card(
                      elevation: 4,
                      clipBehavior: Clip.antiAlias,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Stack(
                        alignment: Alignment.bottomLeft,
                        children: [
                          Container(
                            height: 180,
                            width: double.infinity,
                            color: Colors.blueGrey.shade800,
                            child: const Center(
                              child: Icon(Icons.image, size: 60, color: Colors.white54),
                            ),
                          ),
                          // Dark gradient overlay
                          Container(
                            height: 180,
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Colors.transparent, Colors.black87],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                              ),
                            ),
                          ),
                          // Badge positioned using Stack
                          Positioned(
                            top: 10,
                            left: 10,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                'BREAKING',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          // Article title overlay
                          const Padding(
                            padding: EdgeInsets.all(12.0),
                            child: Text(
                              'Global Tech Summit Reveals New Sustainable Smart Devices',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Section Header: Categories
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                child: Text(
                  'Categories',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),

            // Requirement 2 & 6: Category Cards using SliverGrid
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 2.5,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final item = categories[index];
                    final color = item['color'] as Color;
                    return Card(
                      color: color.withAlpha(35),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(item['icon'] as IconData, color: color),
                          const SizedBox(width: 8),
                          Text(
                            item['title'] as String,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: color,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                  childCount: categories.length,
                ),
              ),
            ),

            // Section Header: Latest News
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(12.0, 16.0, 12.0, 4.0),
                child: Text(
                  'Latest News',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),

            // Requirement 1 & 6: News Articles using SliverList & ListTile
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final article = newsArticles[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    elevation: 1.5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.indigo.shade50,
                        child: const Icon(Icons.article, color: Colors.indigo),
                      ),
                      title: Text(
                        article['title']!,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(article['subtitle']!),
                      trailing: Text(
                        article['time']!,
                        style: const TextStyle(fontSize: 11, color: Colors.grey),
                      ),
                    ),
                  );
                },
                childCount: newsArticles.length,
              ),
            ),

            const SliverToBoxAdapter(
              child: SizedBox(height: 20),
            ),
          ],
        ),
      ),
    );
  }
}
