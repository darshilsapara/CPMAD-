import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: VideoFeedScreen(),
  ));
}

class VideoFeedScreen extends StatelessWidget {
  const VideoFeedScreen({super.key});

  final List<String> categories = const [
    'All',
    'Flutter',
    'Music',
    'Gaming',
    'Podcast',
    'Tech'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('StreamHub Video Feed'),
        backgroundColor: Colors.redAccent,
      ),
      body: ListView(
        children: [
          // 1. Featured Content using Stack
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  height: 180,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(
                    child: Text(
                      'FEATURED PREMIERE',
                      style: TextStyle(color: Colors.white54, letterSpacing: 1.5),
                    ),
                  ),
                ),
                // Play Icon Button overlay
                const CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.redAccent,
                  child: Icon(Icons.play_arrow, color: Colors.white, size: 36),
                ),
                // Duration Tag
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    color: Colors.black54,
                    child: const Text(
                      '12:45',
                      style: TextStyle(color: Colors.white, fontSize: 11),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Horizontal Category Chips
          SizedBox(
            height: 42,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              itemCount: categories.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.only(right: 6.0),
                child: Chip(
                  label: Text(categories[index]),
                  backgroundColor: index == 0 ? Colors.redAccent.shade100 : Colors.grey.shade200,
                ),
              ),
            ),
          ),

          const SizedBox(height: 8),

          // 3. Video Feed List using ListView & ListTile
          ...List.generate(
            5,
            (index) => Card(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              elevation: 2,
              child: ListTile(
                leading: Container(
                  width: 90,
                  height: 55,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(Icons.videocam, color: Colors.black45),
                ),
                title: Text(
                  'Flutter Tutorial #${index + 1}: Modern UI Design',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text('Code Channel • ${(index + 1) * 15}K views • 2 days ago'),
                trailing: const Icon(Icons.more_vert),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
