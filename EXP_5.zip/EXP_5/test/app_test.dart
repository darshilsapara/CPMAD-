import 'package:flutter_test/flutter_test.dart';
import 'package:shopping_app/main.dart';

void main() {
  testWidgets('product details pass the selected product to the cart', (
    tester,
  ) async {
    await tester.pumpWidget(const ShoppingApp());

    await tester.tap(find.text('Products'));
    await tester.pumpAndSettle();
    expect(find.byType(ProductListScreen), findsOneWidget);
    await tester.tap(find.byType(ProductCard).first);
    await tester.pumpAndSettle();
    expect(find.byType(ProductDetailsScreen), findsOneWidget);
    expect(find.text('Product Details'), findsOneWidget);
    await tester.tap(find.text('Add to cart'));
    await tester.pumpAndSettle();

    expect(find.text('Cart'), findsOneWidget);
    expect(find.text('Headphones'), findsOneWidget);
    expect(find.text('\$49.99'), findsOneWidget);
  });

  testWidgets('bottom navigation preserves each section navigation stack', (
    tester,
  ) async {
    await tester.pumpWidget(const ShoppingApp());

    await tester.tap(find.text('Products'));
    await tester.pumpAndSettle();
    await tester.tap(find.byType(ProductCard).first);
    await tester.pumpAndSettle();
    expect(find.text('Product Details'), findsOneWidget);

    await tester.tap(find.text('Home'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Products'));
    await tester.pumpAndSettle();

    expect(find.text('Product Details'), findsOneWidget);
  });

  testWidgets('student details receive the selected name', (tester) async {
    await tester.pumpWidget(const ShoppingApp());

    await tester.tap(find.byTooltip('Open navigation menu'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Student List'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Aarav'));
    await tester.pumpAndSettle();

    expect(find.text('Student: Aarav'), findsOneWidget);
  });

  testWidgets('food selection is passed through to the cart', (tester) async {
    await tester.pumpWidget(const ShoppingApp());

    await tester.tap(find.byTooltip('Open navigation menu'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Food Ordering'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Italian'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Pasta House'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Cheese Pasta'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Add to cart'));
    await tester.pumpAndSettle();

    expect(find.text('Cart'), findsOneWidget);
    expect(find.text('Cheese Pasta'), findsOneWidget);
    expect(find.text('\$12.50'), findsOneWidget);
  });
}
