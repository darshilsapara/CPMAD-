# Shopping Application

A beginner Flutter app demonstrating named navigation, route arguments, a
drawer, bottom navigation with separate navigation stacks, product category
tabs, and tap/long-press gestures.

The app includes the shopping screens and product-to-cart flow, plus the first
two post-experiment exercises: student list/details/settings and food
categories/restaurants/details/cart.

Run the app with:

```shell
flutter run
```
