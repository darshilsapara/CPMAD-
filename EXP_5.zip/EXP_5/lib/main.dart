import 'package:flutter/material.dart';

void main() {
  runApp(const ShoppingApp());
}

class Product {
  const Product(this.name, this.category, this.price, this.emoji);

  final String name;
  final String category;
  final double price;
  final String emoji;
}

class Restaurant {
  const Restaurant(this.name, this.category);

  final String name;
  final String category;
}

class Food {
  const Food(this.name, this.restaurant, this.price, this.emoji);

  final String name;
  final String restaurant;
  final double price;
  final String emoji;
}

const products = [
  Product('Headphones', 'Electronics', 49.99, '🎧'),
  Product('Smart Watch', 'Electronics', 79.99, '⌚'),
  Product('T-shirt', 'Fashion', 19.99, '👕'),
  Product('Backpack', 'Fashion', 34.99, '🎒'),
  Product('Desk Lamp', 'Home', 24.99, '💡'),
  Product('Coffee Mug', 'Home', 9.99, '☕'),
];

const restaurants = [
  Restaurant('Pasta House', 'Italian'),
  Restaurant('Burger Corner', 'Fast Food'),
  Restaurant('Sweet Treats', 'Cafe'),
];

const foods = [
  Food('Cheese Pasta', 'Pasta House', 12.50, '🍝'),
  Food('Margherita Pizza', 'Pasta House', 14.00, '🍕'),
  Food('Classic Burger', 'Burger Corner', 9.50, '🍔'),
  Food('French Fries', 'Burger Corner', 4.00, '🍟'),
  Food('Chocolate Cake', 'Sweet Treats', 6.50, '🍰'),
  Food('Iced Coffee', 'Sweet Treats', 4.50, '🧋'),
];

class ShoppingApp extends StatelessWidget {
  const ShoppingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shopping App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedTab = 0;
  final navigatorKeys = List.generate(3, (_) => GlobalKey<NavigatorState>());

  Route<dynamic> buildRoute(int tab, RouteSettings settings) {
    late final Widget page;

    switch (settings.name) {
      case '/':
        if (tab == 0) {
          page = HomeScreen(onSelectTab: selectTab);
        } else if (tab == 1) {
          page = const ProductListScreen();
        } else {
          page = const ProfileScreen();
        }
      case '/products':
        page = const ProductListScreen();
      case '/profile':
        page = const ProfileScreen();
      case '/product-details':
        page = ProductDetailsScreen(product: settings.arguments as Product);
      case '/cart':
        page = CartScreen(item: settings.arguments);
      case '/students':
        page = const StudentListScreen();
      case '/student-details':
        page = StudentDetailsScreen(name: settings.arguments as String);
      case '/settings':
        page = const SettingsScreen();
      case '/categories':
        page = const CategoryScreen();
      case '/restaurants':
        page = RestaurantScreen(category: settings.arguments as String);
      case '/food-list':
        page = FoodListScreen(restaurant: settings.arguments as Restaurant);
      case '/food-details':
        page = FoodDetailsScreen(food: settings.arguments as Food);
      default:
        throw FlutterError('Unknown route: ${settings.name}');
    }

    return MaterialPageRoute<void>(builder: (_) => page, settings: settings);
  }

  void selectTab(int index) {
    setState(() => selectedTab = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: selectedTab,
        children: List.generate(
          3,
          (index) => Navigator(
            key: navigatorKeys[index],
            onGenerateRoute: (settings) => buildRoute(index, settings),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedTab,
        onTap: selectTab,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_bag),
            label: 'Products',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.onSelectTab});

  final ValueChanged<int> onSelectTab;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shopping Home')),
      drawer: AppDrawer(onSelectTab: onSelectTab),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Welcome!', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          const Text('Find something you love today.'),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => onSelectTab(1),
            icon: const Icon(Icons.shopping_bag),
            label: const Text('Browse products'),
          ),
          const SizedBox(height: 20),
          Text(
            'Popular products',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          ...products
              .take(3)
              .map(
                (product) => ListTile(
                  leading: Text(
                    product.emoji,
                    style: const TextStyle(fontSize: 28),
                  ),
                  title: Text(product.name),
                  subtitle: Text('\$${product.price.toStringAsFixed(2)}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.pushNamed(
                    context,
                    '/product-details',
                    arguments: product,
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key, required this.onSelectTab});

  final ValueChanged<int> onSelectTab;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.indigo),
            child: Align(
              alignment: Alignment.bottomLeft,
              child: Text(
                'App Menu',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
          ),
          _tabItem(context, 'Home', Icons.home, 0),
          _tabItem(context, 'Products', Icons.shopping_bag, 1),
          _tabItem(context, 'Profile', Icons.person, 2),
          const Divider(),
          _routeItem(context, 'Student List', Icons.school, '/students'),
          _routeItem(context, 'Settings', Icons.settings, '/settings'),
          _routeItem(context, 'Food Ordering', Icons.restaurant, '/categories'),
        ],
      ),
    );
  }

  Widget _tabItem(
    BuildContext context,
    String title,
    IconData icon,
    int index,
  ) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        onSelectTab(index);
      },
    );
  }

  Widget _routeItem(
    BuildContext context,
    String title,
    IconData icon,
    String route,
  ) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      },
    );
  }
}

class ProductListScreen extends StatelessWidget {
  const ProductListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const categories = ['All', 'Electronics', 'Fashion', 'Home'];

    return DefaultTabController(
      length: categories.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Products'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'All'),
              Tab(text: 'Electronics'),
              Tab(text: 'Fashion'),
              Tab(text: 'Home'),
            ],
          ),
        ),
        body: TabBarView(
          children: categories.map((category) {
            final shownProducts = category == 'All'
                ? products
                : products.where((product) => product.category == category);
            return GridView.count(
              padding: const EdgeInsets.all(12),
              crossAxisCount: 2,
              childAspectRatio: 0.9,
              children: shownProducts
                  .map((product) => ProductCard(product: product))
                  .toList(),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class ProductCard extends StatefulWidget {
  const ProductCard({super.key, required this.product});

  final Product product;

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    return GestureDetector(
      onTap: () =>
          Navigator.pushNamed(context, '/product-details', arguments: product),
      onLongPress: () {
        setState(() => isFavorite = !isFavorite);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              isFavorite
                  ? '${product.name} added to favorites'
                  : '${product.name} removed from favorites',
            ),
          ),
        );
      },
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: Icon(
                  isFavorite ? Icons.favorite : Icons.favorite_border,
                  color: isFavorite ? Colors.red : null,
                ),
              ),
              Text(product.emoji, style: const TextStyle(fontSize: 42)),
              const SizedBox(height: 8),
              Text(product.name, textAlign: TextAlign.center),
              Text('\$${product.price.toStringAsFixed(2)}'),
            ],
          ),
        ),
      ),
    );
  }
}

class ProductDetailsScreen extends StatelessWidget {
  const ProductDetailsScreen({super.key, required this.product});

  final Product product;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(product.emoji, style: const TextStyle(fontSize: 80)),
            Text(
              product.name,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            Text(product.category),
            Text('\$${product.price.toStringAsFixed(2)}'),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () =>
                  Navigator.pushNamed(context, '/cart', arguments: product),
              child: const Text('Add to cart'),
            ),
          ],
        ),
      ),
    );
  }
}

class CartScreen extends StatelessWidget {
  const CartScreen({super.key, required this.item});

  final Object? item;

  @override
  Widget build(BuildContext context) {
    String name = 'No item selected';
    String emoji = '🛒';
    double? price;

    if (item is Product) {
      name = (item as Product).name;
      emoji = (item as Product).emoji;
      price = (item as Product).price;
    } else if (item is Food) {
      name = (item as Food).name;
      emoji = (item as Food).emoji;
      price = (item as Food).price;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Cart')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 64)),
            Text(name, style: Theme.of(context).textTheme.headlineSmall),
            if (price != null) Text('\$${price.toStringAsFixed(2)}'),
          ],
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(radius: 36, child: Icon(Icons.person, size: 40)),
            SizedBox(height: 12),
            Text('Guest User'),
          ],
        ),
      ),
    );
  }
}

class StudentListScreen extends StatelessWidget {
  const StudentListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const students = ['Aarav', 'Diya', 'Rohan'];

    return Scaffold(
      appBar: AppBar(title: const Text('Student List')),
      body: ListView(
        children: students
            .map(
              (student) => ListTile(
                leading: const Icon(Icons.school),
                title: Text(student),
                onTap: () => Navigator.pushNamed(
                  context,
                  '/student-details',
                  arguments: student,
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class StudentDetailsScreen extends StatelessWidget {
  const StudentDetailsScreen({super.key, required this.name});

  final String name;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Details')),
      body: Center(child: Text('Student: $name')),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: const ListTile(
        leading: Icon(Icons.notifications),
        title: Text('Notifications'),
        trailing: Switch(value: true, onChanged: null),
      ),
    );
  }
}

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const categories = ['Italian', 'Fast Food', 'Cafe'];

    return Scaffold(
      appBar: AppBar(title: const Text('Food Categories')),
      body: ListView(
        children: categories
            .map(
              (category) => ListTile(
                leading: const Icon(Icons.restaurant_menu),
                title: Text(category),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.pushNamed(
                  context,
                  '/restaurants',
                  arguments: category,
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class RestaurantScreen extends StatelessWidget {
  const RestaurantScreen({super.key, required this.category});

  final String category;

  @override
  Widget build(BuildContext context) {
    final matchingRestaurants = restaurants.where(
      (restaurant) => restaurant.category == category,
    );

    return Scaffold(
      appBar: AppBar(title: Text('$category Restaurants')),
      body: ListView(
        children: matchingRestaurants
            .map(
              (restaurant) => ListTile(
                leading: const Icon(Icons.store),
                title: Text(restaurant.name),
                onTap: () => Navigator.pushNamed(
                  context,
                  '/food-list',
                  arguments: restaurant,
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class FoodListScreen extends StatelessWidget {
  const FoodListScreen({super.key, required this.restaurant});

  final Restaurant restaurant;

  @override
  Widget build(BuildContext context) {
    final menu = foods.where((food) => food.restaurant == restaurant.name);

    return Scaffold(
      appBar: AppBar(title: Text(restaurant.name)),
      body: ListView(
        children: menu
            .map(
              (food) => ListTile(
                leading: Text(food.emoji, style: const TextStyle(fontSize: 28)),
                title: Text(food.name),
                subtitle: Text('\$${food.price.toStringAsFixed(2)}'),
                onTap: () => Navigator.pushNamed(
                  context,
                  '/food-details',
                  arguments: food,
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

class FoodDetailsScreen extends StatelessWidget {
  const FoodDetailsScreen({super.key, required this.food});

  final Food food;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Food Details')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(food.emoji, style: const TextStyle(fontSize: 72)),
            Text(food.name, style: Theme.of(context).textTheme.headlineSmall),
            Text(food.restaurant),
            Text('\$${food.price.toStringAsFixed(2)}'),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () =>
                  Navigator.pushNamed(context, '/cart', arguments: food),
              child: const Text('Add to cart'),
            ),
          ],
        ),
      ),
    );
  }
}
