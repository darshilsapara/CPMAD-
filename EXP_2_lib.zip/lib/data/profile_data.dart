/// Simple data class for developer profile (no state management needed).
class ProfileData {
  final String name;
  final String qualification;
  final String email;
  final String phone;
  final String location;
  final String imageUrl;
  final List<String> skills;

  const ProfileData({
    required this.name,
    required this.qualification,
    required this.email,
    required this.phone,
    required this.location,
    required this.imageUrl,
    required this.skills,
  });
}

/// Developer profile data for Darshil Sapara.
const developerProfile = ProfileData(
  name: 'Darshil Sapara',
  qualification: 'B.Tech',
  email: 'darshil@gmail.com',
  phone: '9999999999',
  location: 'Rajkot, Gujarat',
  imageUrl:
      'https://raw.githubusercontent.com/flutter/flutter/master/docs/images/flutter-logo.png',
  skills: ['Flutter', 'Dart', 'HTML', 'CSS', 'Git'],
);
