import 'package:flutter/material.dart';

/// Custom colors for the portfolio app.
class AppColors {
  static const Color primary = Color(0xFFC62828); // red shade
  static const Color secondary = Color(0xFFE53935);
  static const Color cardBackground = Color(0xFFFFEBEE); // light red tint
  static const Color textDark = Color(0xFF212121);
  static const Color textLight = Color(0xFF616161);
}

/// Application theme with custom colors and text styles.
class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        primary: AppColors.primary,
        secondary: AppColors.secondary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: AppColors.cardBackground,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      textTheme: const TextTheme(
        headlineMedium: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
          color: AppColors.textDark,
        ),
        titleMedium: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: AppColors.textDark,
        ),
        bodyMedium: TextStyle(
          fontSize: 14,
          color: AppColors.textLight,
        ),
      ),
    );
  }
}
