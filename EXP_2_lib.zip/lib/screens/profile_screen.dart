import 'package:flutter/material.dart';
import '../data/profile_data.dart';
import '../theme/app_theme.dart';
import '../widgets/contact_item.dart';
import '../widgets/skill_card.dart';

/// Developer profile screen.
/// Uses: Scaffold, AppBar, SafeArea, Row, Column, Container, Card,
/// Expanded, Flexible, Image, Icon, Text, theme, reusable widgets.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final profile = developerProfile;

    // 1. Scaffold + AppBar
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Developer Profile'),
        leading: const Icon(Icons.person),
      ),
      // 2. SafeArea
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildProfileHeader(context, profile),
              const SizedBox(height: 16),
              _buildSkillsSection(context, profile.skills),
              const SizedBox(height: 16),
              _buildContactSection(context, profile),
            ],
          ),
        ),
      ),
    );
  }

  /// Profile image, name, qualification — Card, Container, Row, Column,
  /// Expanded, Flexible, Image, Icon, Text.
  Widget _buildProfileHeader(BuildContext context, ProfileData profile) {
    return Card(
      child: Container(
        padding: const EdgeInsets.all(16),
        width: double.infinity,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary, width: 2),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  profile.imageUrl,
                  width: 90,
                  height: 90,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    width: 90,
                    height: 90,
                    color: AppColors.cardBackground,
                    child: const Icon(Icons.person, size: 50, color: AppColors.primary),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    profile.name,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.school, size: 20, color: AppColors.primary),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          profile.qualification,
                          style: Theme.of(context).textTheme.bodyMedium,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Skills — reusable SkillCard widget, Card, Container, Row, Column.
  Widget _buildSkillsSection(BuildContext context, List<String> skills) {
    return Card(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.star, color: AppColors.primary, size: 22),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Skills',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    children: skills
                        .sublist(0, (skills.length / 2).ceil())
                        .map((skill) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: SkillCard(skillName: skill),
                            ))
                        .toList(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    children: skills
                        .sublist((skills.length / 2).ceil())
                        .map((skill) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: SkillCard(skillName: skill),
                            ))
                        .toList(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Contact — reusable ContactItem widget, Card, Container, Column.
  Widget _buildContactSection(BuildContext context, ProfileData profile) {
    return Card(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.contact_phone, color: AppColors.primary),
                const SizedBox(width: 8),
                Text('Contact Information', style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            ContactItem(
              icon: Icons.email,
              label: 'Email',
              value: profile.email,
            ),
            ContactItem(
              icon: Icons.phone,
              label: 'Phone',
              value: profile.phone,
            ),
            ContactItem(
              icon: Icons.location_on,
              label: 'Location',
              value: profile.location,
            ),
          ],
        ),
      ),
    );
  }
}
