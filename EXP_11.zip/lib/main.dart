import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (DefaultFirebaseOptions.currentPlatform.apiKey == 'YOUR_API_KEY') {
    runApp(
      const MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text('Configure Firebase with flutterfire configure.'),
          ),
        ),
      ),
    );
    return;
  }
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const StudentApp());
}

class StudentApp extends StatelessWidget {
  const StudentApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Student Management',
    theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
    home: StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.hasError) {
          return Scaffold(body: Center(child: Text('${snapshot.error}')));
        }
        return snapshot.data == null
            ? const LoginPage()
            : StudentPage(user: snapshot.data!);
      },
    ),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  String _role = 'Student';

  void _message(String text) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    try {
      final auth = FirebaseAuth.instance;
      if (_register) {
        final credential = await auth.createUserWithEmailAndPassword(
          email: _email.text.trim(),
          password: _password.text,
        );
        await credential.user!.updateDisplayName(_name.text.trim());
        await FirebaseFirestore.instance
            .collection('users')
            .doc(credential.user!.uid)
            .set({'name': _name.text.trim(), 'role': _role});
      } else {
        await auth.signInWithEmailAndPassword(
          email: _email.text.trim(),
          password: _password.text,
        );
      }
    } on FirebaseAuthException catch (error) {
      _message(error.message ?? 'Authentication failed.');
    } on FirebaseException catch (error) {
      _message(error.message ?? 'Could not save your profile.');
    }
  }

  Future<void> _resetPassword() async {
    if (_email.text.trim().isEmpty) {
      _message('Enter your email first.');
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: _email.text.trim(),
      );
      _message('Password reset email sent.');
    } on FirebaseAuthException catch (error) {
      _message(error.message ?? 'Could not send reset email.');
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Student Management')),
    body: Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: SizedBox(
          width: 400,
          child: Form(
            key: _form,
            child: Column(
              children: [
                Text(_register ? 'Register' : 'Login'),
                if (_register) ...[
                  TextFormField(
                    controller: _name,
                    decoration: const InputDecoration(labelText: 'Name'),
                    validator: (v) =>
                        v == null || v.trim().isEmpty ? 'Enter name' : null,
                  ),
                  DropdownButtonFormField<String>(
                    initialValue: _role,
                    decoration: const InputDecoration(labelText: 'Role'),
                    items: const [
                      DropdownMenuItem(
                        value: 'Student',
                        child: Text('Student'),
                      ),
                      DropdownMenuItem(
                        value: 'Teacher',
                        child: Text('Teacher'),
                      ),
                    ],
                    onChanged: (v) => setState(() => _role = v ?? 'Student'),
                  ),
                ],
                TextFormField(
                  controller: _email,
                  decoration: const InputDecoration(labelText: 'Email'),
                  validator: (v) => v == null || !v.contains('@')
                      ? 'Enter valid email'
                      : null,
                ),
                TextFormField(
                  controller: _password,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password'),
                  validator: (v) => v == null || v.length < 6
                      ? 'At least 6 characters'
                      : null,
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: _submit,
                  child: Text(_register ? 'Register' : 'Login'),
                ),
                TextButton(
                  onPressed: () => setState(() => _register = !_register),
                  child: Text(
                    _register ? 'Have an account? Login' : 'Register',
                  ),
                ),
                if (!_register)
                  TextButton(
                    onPressed: _resetPassword,
                    child: const Text('Reset password'),
                  ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}

class StudentPage extends StatefulWidget {
  const StudentPage({required this.user, super.key});

  final User user;

  @override
  State<StudentPage> createState() => _StudentPageState();
}

class _StudentPageState extends State<StudentPage> {
  final _search = TextEditingController();
  final _students = FirebaseFirestore.instance.collection('students');

  void _message(String text) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  Future<void> _studentDialog([DocumentSnapshot? student]) async {
    final data = student?.data() as Map<String, dynamic>?;
    final name = TextEditingController(text: data?['name'] as String? ?? '');
    final email = TextEditingController(text: data?['email'] as String? ?? '');
    final course = TextEditingController(
      text: data?['course'] as String? ?? '',
    );
    final form = GlobalKey<FormState>();
    final values = await showDialog<List<String>>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(student == null ? 'Add student' : 'Edit student'),
        content: Form(
          key: form,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _field(name, 'Name'),
              _field(email, 'Email'),
              _field(course, 'Course'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (form.currentState!.validate()) {
                Navigator.pop(context, [
                  name.text.trim(),
                  email.text.trim(),
                  course.text.trim(),
                ]);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    name.dispose();
    email.dispose();
    course.dispose();
    if (values == null) return;
    try {
      final record = {
        'name': values[0],
        'email': values[1],
        'course': values[2],
      };
      if (student == null) {
        await _students.add(record);
      } else {
        await _students.doc(student.id).update(record);
      }
    } on FirebaseException catch (error) {
      _message(error.message ?? 'Could not save student.');
    }
  }

  Widget _field(TextEditingController controller, String label) =>
      TextFormField(
        controller: controller,
        decoration: InputDecoration(labelText: label),
        validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
      );

  Future<void> _editProfile() async {
    final name = TextEditingController(text: widget.user.displayName ?? '');
    final newName = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Update profile'),
        content: TextField(
          controller: name,
          decoration: const InputDecoration(labelText: 'Name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, name.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    name.dispose();
    if (newName == null || newName.isEmpty) return;
    try {
      await widget.user.updateDisplayName(newName);
      await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.user.uid)
          .update({'name': newName});
      _message('Profile updated.');
    } on FirebaseAuthException catch (error) {
      _message(error.message ?? 'Could not update profile.');
    } on FirebaseException catch (error) {
      _message(error.message ?? 'Could not update profile.');
    }
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.user.displayName ?? widget.user.email ?? 'Students'),
      actions: [
        IconButton(
          tooltip: 'Edit profile',
          onPressed: _editProfile,
          icon: const Icon(Icons.person),
        ),
        IconButton(
          tooltip: 'Logout',
          onPressed: () => FirebaseAuth.instance.signOut(),
          icon: const Icon(Icons.logout),
        ),
      ],
    ),
    body: Column(
      children: [
        TextField(
          controller: _search,
          decoration: const InputDecoration(
            labelText: 'Search name, email or course',
            prefixIcon: Icon(Icons.search),
          ),
          onChanged: (_) => setState(() {}),
        ),
        Expanded(
          child: StreamBuilder(
            stream: _students.snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('Error: ${snapshot.error}');
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final query = _search.text.toLowerCase();
              final records = snapshot.data!.docs.where((doc) {
                final data = doc.data();
                return ['name', 'email', 'course'].any(
                  (key) => (data[key] as String? ?? '').toLowerCase().contains(
                    query,
                  ),
                );
              }).toList();
              return ListView(
                children: records.map((doc) {
                  final data = doc.data();
                  return ListTile(
                    title: Text(data['name'] as String? ?? ''),
                    subtitle: Text(
                      '${data['email'] ?? ''} | ${data['course'] ?? ''}',
                    ),
                    onTap: () => _studentDialog(doc),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () async {
                        try {
                          await _students.doc(doc.id).delete();
                        } on FirebaseException catch (error) {
                          _message(
                            error.message ?? 'Could not delete student.',
                          );
                        }
                      },
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ),
      ],
    ),
    floatingActionButton: FloatingActionButton(
      onPressed: () => _studentDialog(),
      child: const Icon(Icons.add),
    ),
  );
}
