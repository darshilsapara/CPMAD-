import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting();
  runApp(const StudentApp());
}

class StudentApp extends StatefulWidget {
  const StudentApp({super.key});

  @override
  State<StudentApp> createState() => _StudentAppState();
}

class _StudentAppState extends State<StudentApp> {
  static const _languages = ['en', 'gu', 'hi'];
  static const _languageNames = {
    'en': 'English',
    'gu': 'ગુજરાતી',
    'hi': 'हिन्दी',
  };
  static const _translations = {
    'en': {
      'title': 'Student Information',
      'name': 'Name',
      'course': 'Course',
      'admission': 'Admission date',
      'marks': 'Marks',
      'calculator': 'Calculator',
      'first': 'First number',
      'second': 'Second number',
      'add': 'Add',
      'result': 'Result',
      'expenses': 'Expense Manager',
      'expenseName': 'Expense name',
      'amount': 'Amount (₹)',
      'addExpense': 'Add expense',
      'total': 'Total',
      'invalid': 'Enter valid values.',
    },
    'gu': {
      'title': 'વિદ્યાર્થીની માહિતી',
      'name': 'નામ',
      'course': 'અભ્યાસક્રમ',
      'admission': 'પ્રવેશ તારીખ',
      'marks': 'ગુણ',
      'calculator': 'કેલ્ક્યુલેટર',
      'first': 'પહેલી સંખ્યા',
      'second': 'બીજી સંખ્યા',
      'add': 'ઉમેરો',
      'result': 'જવાબ',
      'expenses': 'ખર્ચ વ્યવસ્થાપક',
      'expenseName': 'ખર્ચનું નામ',
      'amount': 'રકમ (₹)',
      'addExpense': 'ખર્ચ ઉમેરો',
      'total': 'કુલ',
      'invalid': 'યોગ્ય માહિતી દાખલ કરો.',
    },
    'hi': {
      'title': 'छात्र जानकारी',
      'name': 'नाम',
      'course': 'पाठ्यक्रम',
      'admission': 'प्रवेश तिथि',
      'marks': 'अंक',
      'calculator': 'कैलकुलेटर',
      'first': 'पहली संख्या',
      'second': 'दूसरी संख्या',
      'add': 'जोड़ें',
      'result': 'उत्तर',
      'expenses': 'खर्च प्रबंधक',
      'expenseName': 'खर्च का नाम',
      'amount': 'राशि (₹)',
      'addExpense': 'खर्च जोड़ें',
      'total': 'कुल',
      'invalid': 'सही जानकारी दर्ज करें।',
    },
  };

  late SharedPreferences _preferences;
  String _language = 'en';
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _loadLanguage();
  }

  Future<void> _loadLanguage() async {
    _preferences = await SharedPreferences.getInstance();
    final savedLanguage = _preferences.getString('language') ?? 'en';
    if (!mounted) return;
    setState(() {
      _language = _languages.contains(savedLanguage) ? savedLanguage : 'en';
      _ready = true;
    });
  }

  Future<void> _changeLanguage(String? language) async {
    if (language == null) return;
    setState(() => _language = language);
    await _preferences.setString('language', language);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: Locale(_language),
      supportedLocales: const [Locale('en'), Locale('gu'), Locale('hi')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: _ready
          ? StudentHome(
              language: _language,
              onLanguageChanged: _changeLanguage,
            )
          : const _LoadingPage(),
    );
  }
}

class _LoadingPage extends StatelessWidget {
  const _LoadingPage();

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator()));
}

class Expense {
  const Expense(this.name, this.amount, this.date);

  final String name;
  final double amount;
  final DateTime date;
}

class StudentHome extends StatefulWidget {
  const StudentHome({
    required this.language,
    required this.onLanguageChanged,
    super.key,
  });

  final String language;
  final ValueChanged<String> onLanguageChanged;

  @override
  State<StudentHome> createState() => _StudentHomeState();
}

class _StudentHomeState extends State<StudentHome> {
  final _firstController = TextEditingController();
  final _secondController = TextEditingController();
  final _expenseNameController = TextEditingController();
  final _expenseAmountController = TextEditingController();
  final List<Expense> _expenses = [];
  String? _calculatorMessage;
  String? _expenseMessage;

  String get _locale => '${widget.language}_IN';
  String t(String key) =>
      _StudentAppState._translations[widget.language]![key]!;

  @override
  void dispose() {
    _firstController.dispose();
    _secondController.dispose();
    _expenseNameController.dispose();
    _expenseAmountController.dispose();
    super.dispose();
  }

  void _calculate() {
    final first = double.tryParse(_firstController.text);
    final second = double.tryParse(_secondController.text);
    setState(() {
      _calculatorMessage = first == null || second == null
          ? t('invalid')
          : '${t('result')}: ${NumberFormat.decimalPattern(_locale).format(first + second)}';
    });
  }

  void _addExpense() {
    final name = _expenseNameController.text.trim();
    final amount = double.tryParse(_expenseAmountController.text);
    if (name.isEmpty || amount == null || amount <= 0) {
      setState(() => _expenseMessage = t('invalid'));
      return;
    }

    setState(() {
      _expenses.add(Expense(name, amount, DateTime.now()));
      _expenseMessage = null;
      _expenseNameController.clear();
      _expenseAmountController.clear();
    });
  }

  NumberFormat get _currency =>
      NumberFormat.currency(locale: _locale, name: 'INR', symbol: '₹');

  Widget _section(String title, List<Widget> children) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              ...children,
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final numberFormat = NumberFormat.decimalPattern(_locale);
    final admissionDate =
        DateFormat.yMMMMd(_locale).format(DateTime(2024, 6, 15));
    final total =
        _expenses.fold<double>(0, (sum, expense) => sum + expense.amount);

    return Scaffold(
      appBar: AppBar(
        title: Text(t('title')),
        actions: [
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: widget.language,
              items: _StudentAppState._languages
                  .map((language) => DropdownMenuItem(
                        value: language,
                        child: Text(_StudentAppState._languageNames[language]!),
                      ))
                  .toList(),
              onChanged: (language) {
                if (language != null) {
                  widget.onLanguageChanged(language);
                }
              },
            ),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section(t('title'), [
            Text('${t('name')}: Asha Patel'),
            Text('${t('course')}: Computer Applications'),
            Text('${t('admission')}: $admissionDate'),
            Text('${t('marks')}: ${numberFormat.format(87)} / 100'),
          ]),
          _section(t('calculator'), [
            TextField(
              controller: _firstController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: t('first')),
            ),
            TextField(
              controller: _secondController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: t('second')),
            ),
            const SizedBox(height: 8),
            FilledButton(onPressed: _calculate, child: Text(t('add'))),
            if (_calculatorMessage != null) Text(_calculatorMessage!),
          ]),
          _section(t('expenses'), [
            TextField(
              controller: _expenseNameController,
              decoration: InputDecoration(labelText: t('expenseName')),
            ),
            TextField(
              controller: _expenseAmountController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: t('amount')),
            ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _addExpense,
              child: Text(t('addExpense')),
            ),
            if (_expenseMessage != null)
              Text(_expenseMessage!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error)),
            const SizedBox(height: 8),
            Text('${t('total')}: ${_currency.format(total)}'),
            ..._expenses.map(
              (expense) => ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(expense.name),
                subtitle: Text(DateFormat.yMMMd(_locale).format(expense.date)),
                trailing: Text(_currency.format(expense.amount)),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}
