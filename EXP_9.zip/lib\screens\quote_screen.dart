import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/quote.dart';
import '../services/api_service.dart';
import 'favorite_screen.dart';

class QuoteScreen extends StatefulWidget {
  const QuoteScreen({super.key});

  @override
  State<QuoteScreen> createState() => _QuoteScreenState();
}

class _QuoteScreenState extends State<QuoteScreen> {
  late Future<Quote> _quoteFuture;
  final List<Quote> _favorites = [];
  String _selectedCategory = 'All';

  final List<String> _categories = [
    'All',
    'Motivation',
    'Success',
    'Life',
    'Education',
  ];

  @override
  void initState() {
    super.initState();
    _loadNewQuote();
  }

  void _loadNewQuote() {
    setState(() {
      _quoteFuture = ApiService.fetchRandomQuote();
    });
  }

  void _toggleFavorite(Quote quote) {
    setState(() {
      final exists = _favorites.any((q) => q.quote == quote.quote);
      if (exists) {
        _favorites.removeWhere((q) => q.quote == quote.quote);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Removed from Favorites')),
        );
      } else {
        _favorites.add(quote);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Added to Favorites')),
        );
      }
    });
  }

  void _shareQuote(Quote quote) {
    final message = '"${quote.quote}"\n\n— ${quote.author}\n\nShared via Quote App';
    Clipboard.setData(ClipboardData(text: message));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Quote formatted and copied to clipboard!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quote App'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite),
            tooltip: 'View Favorites',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FavoriteScreen(
                    favorites: _favorites,
                    onRemove: (quote) {
                      setState(() => _favorites.remove(quote));
                    },
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Category Selector
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade400),
                borderRadius: BorderRadius.circular(10),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedCategory,
                  isExpanded: true,
                  items: _categories.map((category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Text('Category: $category'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => _selectedCategory = value);
                      _loadNewQuote();
                    }
                  },
                ),
              ),
            ),
            const SizedBox(height: 24),

            // FutureBuilder for API Response
            Expanded(
              child: Center(
                child: FutureBuilder<Quote>(
                  future: _quoteFuture,
                  builder: (context, snapshot) {
                    // 1. Loading State
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 12),
                          Text('Fetching quote...'),
                        ],
                      );
                    }

                    // 2. Error State
                    if (snapshot.hasError) {
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.error_outline, color: Colors.red, size: 50),
                          const SizedBox(height: 12),
                          Text(
                            'Error: ${snapshot.error}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.red),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton.icon(
                            onPressed: _loadNewQuote,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Try Again'),
                          ),
                        ],
                      );
                    }

                    // 3. Empty State
                    if (!snapshot.hasData || snapshot.data!.quote.isEmpty) {
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('No quote found for this category.'),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: _loadNewQuote,
                            child: const Text('Fetch Again'),
                          ),
                        ],
                      );
                    }

                    // 4. Success State
                    final quote = snapshot.data!;
                    final isFavorite = _favorites.any((q) => q.quote == quote.quote);

                    return Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '"${quote.quote}"',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 18,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Text(
                                '- ${quote.author}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blueGrey,
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                            // Action buttons: Favorite, Share, Refresh
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                IconButton(
                                  tooltip: 'Favorite',
                                  icon: Icon(
                                    isFavorite ? Icons.favorite : Icons.favorite_border,
                                    color: isFavorite ? Colors.red : Colors.grey,
                                    size: 28,
                                  ),
                                  onPressed: () => _toggleFavorite(quote),
                                ),
                                IconButton(
                                  tooltip: 'Share',
                                  icon: const Icon(Icons.share, color: Colors.blue, size: 28),
                                  onPressed: () => _shareQuote(quote),
                                ),
                                ElevatedButton.icon(
                                  onPressed: _loadNewQuote,
                                  icon: const Icon(Icons.refresh),
                                  label: const Text('New Quote'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
