class Book {
  final String title;
  final String author;

  Book({
    required this.title,
    required this.author,
  });

  factory Book.fromJson(Map<String, dynamic> json) {
    final authors = json['author_name'] as List<dynamic>?;
    return Book(
      title: json['title'] ?? 'No Title Available',
      author: (authors != null && authors.isNotEmpty)
          ? authors[0].toString()
          : 'Unknown Author',
    );
  }
}
