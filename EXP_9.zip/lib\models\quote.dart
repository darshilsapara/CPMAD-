class Quote {
  final int id;
  final String quote;
  final String author;

  Quote({
    required this.id,
    required this.quote,
    required this.author,
  });

  // Factory constructor to parse JSON response
  factory Quote.fromJson(Map<String, dynamic> json) {
    return Quote(
      id: json['id'] ?? 0,
      quote: json['quote'] ?? '',
      author: json['author'] ?? 'Unknown',
    );
  }
}
