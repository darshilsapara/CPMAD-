import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/quote.dart';
import '../models/joke.dart';
import '../models/book.dart';

class ApiService {
  // 1. Fetch Random Quote
  static Future<Quote> fetchRandomQuote() async {
    final url = Uri.parse('https://dummyjson.com/quotes/random');

    try {
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        if (data.isEmpty || (data['quote'] as String).isEmpty) {
          throw Exception('Received empty quote data.');
        }
        return Quote.fromJson(data);
      } else {
        throw Exception('Server Error: HTTP ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // 2. Fetch Random Joke (Post-Experiment Task)
  static Future<Joke> fetchRandomJoke() async {
    final url = Uri.parse('https://official-joke-api.appspot.com/random_joke');

    try {
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return Joke.fromJson(data);
      } else {
        throw Exception('Server Error: HTTP ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // 3. Search Books by Keyword (Post-Experiment Task)
  static Future<List<Book>> searchBooks(String query) async {
    if (query.trim().isEmpty) return [];

    final url = Uri.parse(
      'https://openlibrary.org/search.json?q=${Uri.encodeComponent(query)}&limit=15',
    );

    try {
      final response = await http.get(url).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final List docs = data['docs'] ?? [];
        return docs.map((item) => Book.fromJson(item)).toList();
      } else {
        throw Exception('Server Error: HTTP ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
}
