import 'package:flutter/material.dart';
import '../models/quote.dart';

class FavoriteScreen extends StatelessWidget {
  final List<Quote> favorites;
  final Function(Quote) onRemove;

  const FavoriteScreen({
    super.key,
    required this.favorites,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Favorite Quotes'),
        centerTitle: true,
      ),
      body: favorites.isEmpty
          ? const Center(
              child: Text(
                'No favorite quotes added yet.',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: favorites.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final quote = favorites[index];
                return ListTile(
                  leading: const Icon(Icons.format_quote, color: Colors.blue),
                  title: Text(
                    '"${quote.quote}"',
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text('- ${quote.author}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => onRemove(quote),
                  ),
                );
              },
            ),
    );
  }
}
