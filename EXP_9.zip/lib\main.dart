import 'package:flutter/material.dart';
import 'screens/quote_screen.dart';
import 'screens/joke_screen.dart';
import 'screens/book_search_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'REST API Flutter Lab',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  // Screens corresponding to Main Experiment & Post-Experiment Tasks
  final List<Widget> _screens = const [
    QuoteScreen(),        // Main Experiment + Tasks 1, 2, 3
    JokeScreen(),         // Post-Experiment Task 4
    BookSearchScreen(),   // Post-Experiment Task 5
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.format_quote),
            label: 'Quotes',
          ),
          NavigationDestination(
            icon: Icon(Icons.emoji_emotions),
            label: 'Jokes',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book),
            label: 'Book Search',
          ),
        ],
      ),
    );
  }
}
