import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        return web;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyA_DEMO_KEY_CPMAD_EXP10_CHROME_API_KEY',
    appId: '1:102938475610:web:a1b2c3d4e5f6g7h8i9j0k1',
    messagingSenderId: '102938475610',
    projectId: 'cpmad-realtime-chat-exp10',
    authDomain: 'cpmad-realtime-chat-exp10.firebaseapp.com',
    storageBucket: 'cpmad-realtime-chat-exp10.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyA_DEMO_KEY_CPMAD_EXP10_ANDROID_API_KEY',
    appId: '1:102938475610:android:b2c3d4e5f6g7h8i9j0k1l2',
    messagingSenderId: '102938475610',
    projectId: 'cpmad-realtime-chat-exp10',
    storageBucket: 'cpmad-realtime-chat-exp10.appspot.com',
  );
}
