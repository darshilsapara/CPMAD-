package com.student.student_result_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
