// Student class - properties and methods for result calculation

class Student {
  String name;
  String rollNumber;

  // Map to store subject name and marks
  Map<String, double> subjectMarks;

  Student({
    required this.name,
    required this.rollNumber,
    required this.subjectMarks,
  });

  // Calculate total marks using loop
  double calculateTotal() {
    double total = 0;
    for (double mark in subjectMarks.values) {
      total = total + mark;
    }
    return total;
  }

  // Calculate percentage
  double calculatePercentage() {
    double total = calculateTotal();
    int subjectCount = subjectMarks.length;
    double maxMarks = subjectCount * 100;
    double percentage = (total / maxMarks) * 100;
    return percentage;
  }

  // Grade using conditional statements
  String calculateGrade() {
    double percentage = calculatePercentage();

    if (percentage >= 90) {
      return 'A+';
    } else if (percentage >= 80) {
      return 'A';
    } else if (percentage >= 70) {
      return 'B';
    } else if (percentage >= 60) {
      return 'C';
    } else if (percentage >= 50) {
      return 'D';
    } else if (percentage >= 40) {
      return 'E';
    } else {
      return 'Fail';
    }
  }
}
