import 'package:flutter/material.dart';
import 'student.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Result Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Text controllers for student details
  final TextEditingController nameController = TextEditingController();
  final TextEditingController rollController = TextEditingController();

  // List of five subjects
  final List<String> subjects = [
    'Mathematics',
    'Physics',
    'Chemistry',
    'English',
    'Computer',
  ];

  // One controller for each subject mark
  final List<TextEditingController> markControllers = List.generate(
    5,
    (index) => TextEditingController(),
  );

  bool isLoading = false;
  Student? studentResult;

  // Simulate loading data from server (asynchronous)
  Future<void> calculateResult() async {
    setState(() {
      isLoading = true;
      studentResult = null;
    });

    // Wait 2 seconds to show loading
    await Future.delayed(const Duration(seconds: 2));

    String name = nameController.text.trim();
    String roll = rollController.text.trim();

    if (name.isEmpty || roll.isEmpty) {
      setState(() {
        isLoading = false;
      });
      _showMessage('Please enter name and roll number');
      return;
    }

    // Build map of subject-wise marks
    Map<String, double> marksMap = {};
    for (int i = 0; i < subjects.length; i++) {
      String text = markControllers[i].text.trim();
      if (text.isEmpty) {
        setState(() {
          isLoading = false;
        });
        _showMessage('Please enter marks for all subjects');
        return;
      }

      double? mark = double.tryParse(text);
      if (mark == null || mark < 0 || mark > 100) {
        setState(() {
          isLoading = false;
        });
        _showMessage('Marks must be numbers between 0 and 100');
        return;
      }

      marksMap[subjects[i]] = mark;
    }

    Student student = Student(
      name: name,
      rollNumber: roll,
      subjectMarks: marksMap,
    );

    setState(() {
      isLoading = false;
      studentResult = student;
    });
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    rollController.dispose();
    for (TextEditingController controller in markControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Result Calculator'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Student Details',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Student Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: rollController,
              decoration: const InputDecoration(
                labelText: 'Roll Number',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Subject Marks (out of 100)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            for (int i = 0; i < subjects.length; i++) ...[
              TextField(
                controller: markControllers[i],
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: subjects[i],
                  border: const OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
            ],
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: isLoading ? null : calculateResult,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Calculate Result', style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(height: 24),
            if (isLoading)
              const Column(
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 12),
                  Text('Loading student result...'),
                ],
              ),
            if (studentResult != null) _buildResultCard(studentResult!),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard(Student student) {
    double total = student.calculateTotal();
    double percentage = student.calculatePercentage();
    String grade = student.calculateGrade();

    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Result',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Text('Name: ${student.name}'),
            Text('Roll No: ${student.rollNumber}'),
            const Divider(height: 24),
            const Text(
              'Subject-wise Marks:',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            for (String subject in student.subjectMarks.keys)
              Text('$subject: ${student.subjectMarks[subject]}'),
            const Divider(height: 24),
            Text('Total Marks: $total / 500'),
            Text('Percentage: ${percentage.toStringAsFixed(2)}%'),
            Text(
              'Grade: $grade',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
