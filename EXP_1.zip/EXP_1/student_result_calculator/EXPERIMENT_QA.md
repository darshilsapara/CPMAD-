# Experiment 1 – Student Result Calculator (CO1)

## Aim
To install Flutter, use Dart basics (variables, data types, operators, conditionals, loops, functions, classes, async), and build a Student Result Calculator app.

---

## 1. Flutter environment setup

**Steps:**
1. Download Flutter SDK from https://docs.flutter.dev/get-started/install
2. Add Flutter `bin` folder to system PATH
3. Run `flutter doctor` and fix any issues (Android Studio / VS Code, SDK licenses)
4. Create project: `flutter create student_result_calculator`
5. Run app: `cd student_result_calculator` then `flutter run`

**Answer:** Flutter is installed when `flutter doctor` shows no critical errors. The project is created with `lib/main.dart` as the entry point.

---

## 2. Dart program – five subjects, total and percentage

**Answer:** Marks are stored in a `Map<String, double>`. Total is calculated in `Student.calculateTotal()` using a `for` loop. Percentage is `(total / (5 × 100)) × 100` in `calculatePercentage()`.

**File:** `lib/student.dart`

---

## 3. Grade calculation using conditional statements

**Answer:** Grade is decided with `if–else if–else` on percentage:

| Percentage | Grade |
|------------|-------|
| ≥ 90       | A+    |
| ≥ 80       | A     |
| ≥ 70       | B     |
| ≥ 60       | C     |
| ≥ 50       | D     |
| ≥ 40       | E     |
| &lt; 40    | Fail  |

**Method:** `Student.calculateGrade()`

---

## 4. Student class

**Answer:** Class `Student` has:
- **Properties:** `name`, `rollNumber`, `subjectMarks` (Map)
- **Methods:** `calculateTotal()`, `calculatePercentage()`, `calculateGrade()`

---

## 5. Flutter UI

**Answer:** `lib/main.dart` shows:
- Text fields for name, roll number, and five subjects
- **Calculate Result** button
- Result card with student details, subject marks, total, percentage, and grade

---

## 6. Lists and maps for subject-wise marks

**Answer:**
- **List:** `subjects` – names of five subjects
- **List:** `markControllers` – one text field per subject
- **Map:** `subjectMarks` – key = subject name, value = marks (built when user taps Calculate)

---

## 7. Asynchronous operation (loading simulation)

**Answer:** On **Calculate Result**, `calculateResult()` is `async`. It sets `isLoading = true`, shows `CircularProgressIndicator`, then `await Future.delayed(Duration(seconds: 2))` to simulate fetching data. After delay, the result is computed and displayed.

---

## Dart concepts used (short)

| Concept | Where used |
|---------|------------|
| Variables & data types | `String`, `double`, `int`, `bool` |
| Operators | `+`, `/`, `*`, `>=`, `==` |
| Conditionals | Grade in `calculateGrade()`, validation in `main.dart` |
| Loops | `for` in total calculation and UI |
| Functions | `calculateResult()`, `calculateTotal()`, etc. |
| Classes | `Student`, `MyApp`, `HomePage` |
| Async | `Future`, `async`, `await`, `Future.delayed` |

---

## How to run

```text
cd student_result_calculator
flutter pub get
flutter run
```

Choose Chrome, Windows, or an Android emulator/device.

---

## Viva / short questions

**Q1. What is Flutter?**  
A: Flutter is Google’s UI toolkit to build apps for mobile, web, and desktop from one codebase using Dart.

**Q2. What is the entry point of a Flutter app?**  
A: The `main()` function, which calls `runApp()`.

**Q3. Difference between `StatelessWidget` and `StatefulWidget`?**  
A: Stateless widget does not change after build. Stateful widget can change using `setState()`.

**Q4. What is `setState()`?**  
A: It tells Flutter to rebuild the UI when data changes.

**Q5. What is `async` and `await`?**  
A: `async` marks a function that can wait. `await` pauses until a `Future` (e.g. delay) completes.

**Q6. Why use Map for marks?**  
A: Each subject name is linked to its mark (key–value), which is easy to read and display.

**Q7. Maximum marks in this app?**  
A: 500 (5 subjects × 100 each).

---

## Project structure

```text
student_result_calculator/
  lib/
    main.dart      → UI and async calculate
    student.dart   → Student class and result logic
  EXPERIMENT_QA.md → This file
```
