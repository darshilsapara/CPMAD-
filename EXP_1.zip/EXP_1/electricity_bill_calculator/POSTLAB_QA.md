# Post-Lab Task 2 – Electricity Bill Calculator

## Aim
Calculate electricity bill using different consumption slabs.

## Slab rates

| Units consumed | Rate (Rs. per unit) |
|----------------|---------------------|
| 1 to 100       | 3                   |
| 101 to 200     | 5                   |
| Above 200      | 7                   |

**Example:** 250 units  
= (100 × 3) + (100 × 5) + (50 × 7)  
= 300 + 500 + 350 = **Rs. 1150**

## Files

- `lib/bill.dart` – `ElectricityBill` class with `calculateBill()`  
- `lib/main.dart` – input and result UI  

## Run

```text
cd electricity_bill_calculator
flutter run
```

## Viva questions

**Q. What is slab billing?**  
A. Different rates apply to different ranges of units consumed.

**Q. Which statements are used?**  
A. `if` and `else` to handle each slab step by step.

**Q. Why use `int` for units?**  
A. Units are whole numbers in this simple app.
