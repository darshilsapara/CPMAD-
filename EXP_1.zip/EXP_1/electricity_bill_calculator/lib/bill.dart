// Electricity bill using slab rates

class ElectricityBill {
  String customerName;
  int units;

  ElectricityBill({
    required this.customerName,
    required this.units,
  });

  // Slab-wise bill calculation
  double calculateBill() {
    int u = units;
    double bill = 0;

    if (u <= 0) {
      return 0;
    }

    // Slab 1: 1 to 100 units @ Rs. 3 per unit
    if (u <= 100) {
      bill = u * 3;
      return bill;
    }

    bill = 100 * 3;
    u = u - 100;

    // Slab 2: 101 to 200 units @ Rs. 5 per unit
    if (u <= 100) {
      bill = bill + (u * 5);
      return bill;
    }

    bill = bill + (100 * 5);
    u = u - 100;

    // Slab 3: above 200 units @ Rs. 7 per unit
    bill = bill + (u * 7);
    return bill;
  }
}
