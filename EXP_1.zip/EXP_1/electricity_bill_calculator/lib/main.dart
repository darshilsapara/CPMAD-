import 'package:flutter/material.dart';
import 'bill.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Electricity Bill Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController unitsController = TextEditingController();

  ElectricityBill? billResult;

  void calculateBill() {
    String name = nameController.text.trim();
    String unitsText = unitsController.text.trim();

    if (name.isEmpty) {
      _showMessage('Please enter customer name');
      return;
    }

    if (unitsText.isEmpty) {
      _showMessage('Please enter units consumed');
      return;
    }

    int? units = int.tryParse(unitsText);
    if (units == null || units < 0) {
      _showMessage('Enter valid units (0 or more)');
      return;
    }

    ElectricityBill bill = ElectricityBill(
      customerName: name,
      units: units,
    );

    setState(() {
      billResult = bill;
    });
  }

  void _showMessage(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    unitsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Electricity Bill Calculator'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Enter Details',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Customer Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: unitsController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Units Consumed',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: calculateBill,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Calculate Bill', style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Slabs: 1–100 units @ Rs.3, 101–200 @ Rs.5, above 200 @ Rs.7',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            if (billResult != null) _buildResult(billResult!),
          ],
        ),
      ),
    );
  }

  Widget _buildResult(ElectricityBill bill) {
    double amount = bill.calculateBill();

    return Card(
      margin: const EdgeInsets.only(top: 24),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Bill Details',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Text('Customer: ${bill.customerName}'),
            Text('Units: ${bill.units}'),
            const Divider(height: 20),
            Text(
              'Total Bill: Rs. ${amount.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.orange,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
