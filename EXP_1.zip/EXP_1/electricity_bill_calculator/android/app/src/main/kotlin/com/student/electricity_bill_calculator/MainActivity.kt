package com.student.electricity_bill_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
