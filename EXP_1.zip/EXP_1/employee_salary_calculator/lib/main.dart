import 'package:flutter/material.dart';
import 'employee.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Employee Salary Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController salaryController = TextEditingController();

  Employee? employeeResult;

  void calculateSalary() {
    String name = nameController.text.trim();
    String salaryText = salaryController.text.trim();

    if (name.isEmpty) {
      _showMessage('Please enter employee name');
      return;
    }

    if (salaryText.isEmpty) {
      _showMessage('Please enter gross salary');
      return;
    }

    double? gross = double.tryParse(salaryText);
    if (gross == null || gross <= 0) {
      _showMessage('Enter a valid salary amount');
      return;
    }

    Employee employee = Employee(name: name, grossSalary: gross);

    setState(() {
      employeeResult = employee;
    });
  }

  void _showMessage(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    salaryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee Salary Calculator'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Enter Details',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Employee Name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: salaryController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Gross Salary (Rs.)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: calculateSalary,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Calculate', style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Rules: Basic = 50% of gross, Allowances = 40% of basic, '
              'Deductions = 12% of basic',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            if (employeeResult != null) _buildResult(employeeResult!),
          ],
        ),
      ),
    );
  }

  Widget _buildResult(Employee emp) {
    double basic = emp.getBasicSalary();
    double allowances = emp.getAllowances();
    double deductions = emp.getDeductions();
    double net = emp.getNetSalary();

    return Card(
      margin: const EdgeInsets.only(top: 24),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Salary Slip',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Text('Name: ${emp.name}'),
            Text('Gross Salary: Rs. ${emp.grossSalary.toStringAsFixed(2)}'),
            const Divider(height: 20),
            Text('Basic Salary: Rs. ${basic.toStringAsFixed(2)}'),
            Text('Allowances: Rs. ${allowances.toStringAsFixed(2)}'),
            Text('Deductions: Rs. ${deductions.toStringAsFixed(2)}'),
            const Divider(height: 20),
            Text(
              'Net Salary: Rs. ${net.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.teal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
