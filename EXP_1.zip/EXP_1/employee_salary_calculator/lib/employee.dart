// Employee salary calculation (basic formulas)

class Employee {
  String name;
  double grossSalary;

  Employee({
    required this.name,
    required this.grossSalary,
  });

  // Basic salary = 50% of gross
  double getBasicSalary() {
    return grossSalary * 0.50;
  }

  // Allowances = 40% of basic salary
  double getAllowances() {
    double basic = getBasicSalary();
    return basic * 0.40;
  }

  // Deductions = 12% of basic salary (example: PF)
  double getDeductions() {
    double basic = getBasicSalary();
    return basic * 0.12;
  }

  // Net salary = basic + allowances - deductions
  double getNetSalary() {
    double basic = getBasicSalary();
    double allowances = getAllowances();
    double deductions = getDeductions();
    return basic + allowances - deductions;
  }
}
