#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\ICT\SEM 5\CPMAD\Flutter\flutter"
export "FLUTTER_APPLICATION_PATH=D:\ICT\SEM 5\CPMAD\EXP_1\employee_salary_calculator"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=D:\ICT\SEM 5\CPMAD\EXP_1\employee_salary_calculator\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
