# Post-Lab Task 1 – Employee Salary Calculator

## Aim
Accept employee salary and calculate basic salary, allowances, deductions, and net salary.

## Formulas used (simple)

| Part | Formula |
|------|---------|
| Basic Salary | 50% of Gross Salary |
| Allowances | 40% of Basic Salary |
| Deductions | 12% of Basic Salary |
| Net Salary | Basic + Allowances − Deductions |

## Files

- `lib/employee.dart` – `Employee` class with calculation methods  
- `lib/main.dart` – input fields and result display  

## Run

```text
cd employee_salary_calculator
flutter run
```

## Viva questions

**Q. What is gross salary?**  
A. Total salary before deductions.

**Q. What is net salary?**  
A. Amount employee gets after adding allowances and subtracting deductions.

**Q. Which Dart topic is used?**  
A. Class, methods, variables (`double`, `String`), and conditionals for validation.
