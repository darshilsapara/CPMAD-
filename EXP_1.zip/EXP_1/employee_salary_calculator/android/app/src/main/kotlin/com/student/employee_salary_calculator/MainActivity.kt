package com.student.employee_salary_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
