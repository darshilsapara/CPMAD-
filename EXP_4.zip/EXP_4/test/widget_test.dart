import 'package:flutter_test/flutter_test.dart';
import 'package:personal_expense_manager/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('Expense Manager app loads and shows title', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const ExpenseManagerApp());
    expect(find.text('Personal Expense Manager'), findsOneWidget);
  });
}
