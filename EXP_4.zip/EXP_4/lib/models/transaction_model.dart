class TransactionItem {
  String id;
  String title;
  double amount;
  String category;
  String type; // 'Expense' or 'Income'
  DateTime date;

  TransactionItem({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.type,
    required this.date,
  });

  // Convert to Map for local JSON persistence
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'category': category,
      'type': type,
      'date': date.toIso8601String(),
    };
  }

  // Create TransactionItem from Map
  factory TransactionItem.fromMap(Map<String, dynamic> map) {
    return TransactionItem(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      amount: (map['amount'] as num?)?.toDouble() ?? 0.0,
      category: map['category'] ?? 'Other',
      type: map['type'] ?? 'Expense',
      date: DateTime.tryParse(map['date'] ?? '') ?? DateTime.now(),
    );
  }
}
