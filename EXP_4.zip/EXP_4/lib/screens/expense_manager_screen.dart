import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/transaction_model.dart';

class ExpenseManagerScreen extends StatefulWidget {
  const ExpenseManagerScreen({super.key});

  @override
  State<ExpenseManagerScreen> createState() => _ExpenseManagerScreenState();
}

class _ExpenseManagerScreenState extends State<ExpenseManagerScreen> {
  List<TransactionItem> _transactions = [];
  Map<String, double> _categoryBudgets = {
    'Food': 5000,
    'Transport': 2000,
    'Bills': 4000,
  };

  final List<String> _categories = [
    'Food',
    'Transport',
    'Bills',
    'Entertainment',
    'Shopping',
    'Salary',
    'Other',
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  // Load saved data from key-value local storage
  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final String? transString = prefs.getString('saved_transactions');
    final String? budgetString = prefs.getString('saved_budgets');

    setState(() {
      if (transString != null) {
        final List decoded = jsonDecode(transString);
        _transactions = decoded.map((e) => TransactionItem.fromMap(e)).toList();
      }
      if (budgetString != null) {
        final Map<String, dynamic> decodedBudget = jsonDecode(budgetString);
        _categoryBudgets = decodedBudget.map(
          (k, v) => MapEntry(k, (v as num).toDouble()),
        );
      }
    });
  }

  // Save current data to key-value local storage
  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    final String transString = jsonEncode(
      _transactions.map((t) => t.toMap()).toList(),
    );
    final String budgetString = jsonEncode(_categoryBudgets);

    await prefs.setString('saved_transactions', transString);
    await prefs.setString('saved_budgets', budgetString);
  }

  // Calculate Total Income
  double get _totalIncome {
    return _transactions
        .where((t) => t.type == 'Income')
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  // Calculate Total Expense
  double get _totalExpense {
    return _transactions
        .where((t) => t.type == 'Expense')
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  // Calculate Net Balance (Income - Expense)
  double get _balance => _totalIncome - _totalExpense;

  // Calculate total expense for a specific category
  double _getCategorySpent(String category) {
    return _transactions
        .where((t) => t.type == 'Expense' && t.category == category)
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  // Open Form to Add or Edit a Transaction
  void _openTransactionForm({TransactionItem? existingItem, int? index}) {
    final titleController = TextEditingController(text: existingItem?.title ?? '');
    final amountController = TextEditingController(
      text: existingItem != null ? existingItem.amount.toStringAsFixed(0) : '',
    );
    String selectedCategory = existingItem?.category ?? 'Food';
    String selectedType = existingItem?.type ?? 'Expense';
    DateTime selectedDate = existingItem?.date ?? DateTime.now();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      existingItem == null ? 'Add Transaction' : 'Edit Transaction',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),

                    // Type Selector (Expense / Income)
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(
                          value: 'Expense',
                          label: Text('Expense'),
                          icon: Icon(Icons.arrow_downward, color: Colors.red),
                        ),
                        ButtonSegment(
                          value: 'Income',
                          label: Text('Income'),
                          icon: Icon(Icons.arrow_upward, color: Colors.green),
                        ),
                      ],
                      selected: {selectedType},
                      onSelectionChanged: (val) {
                        setModalState(() {
                          selectedType = val.first;
                          if (selectedType == 'Income') {
                            selectedCategory = 'Salary';
                          } else if (selectedCategory == 'Salary') {
                            selectedCategory = 'Food';
                          }
                        });
                      },
                    ),
                    const SizedBox(height: 12),

                    // Description Field
                    TextField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: 'Description',
                        prefixIcon: Icon(Icons.description),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Amount Field
                    TextField(
                      controller: amountController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Amount (₹)',
                        prefixIcon: Icon(Icons.currency_rupee),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Category Dropdown
                    DropdownButtonFormField<String>(
                      initialValue: selectedCategory,
                      decoration: const InputDecoration(
                        labelText: 'Category',
                        prefixIcon: Icon(Icons.category),
                        border: OutlineInputBorder(),
                      ),
                      items: _categories.map((cat) {
                        return DropdownMenuItem(value: cat, child: Text(cat));
                      }).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          setModalState(() => selectedCategory = val);
                        }
                      },
                    ),
                    const SizedBox(height: 12),

                    // Date Picker Row
                    Row(
                      children: [
                        const Icon(Icons.calendar_today, color: Colors.grey),
                        const SizedBox(width: 8),
                        Text(
                          'Date: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}',
                          style: const TextStyle(fontSize: 15),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: selectedDate,
                              firstDate: DateTime(2020),
                              lastDate: DateTime(2030),
                            );
                            if (picked != null) {
                              setModalState(() => selectedDate = picked);
                            }
                          },
                          child: const Text('Change Date'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Submit Button
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        backgroundColor: Theme.of(context).primaryColor,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () {
                        final title = titleController.text.trim();
                        final amount = double.tryParse(amountController.text.trim());

                        if (title.isEmpty || amount == null || amount <= 0) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Please enter valid title and amount'),
                            ),
                          );
                          return;
                        }

                        setState(() {
                          if (existingItem == null) {
                            // Add Operation
                            _transactions.add(
                              TransactionItem(
                                id: DateTime.now().millisecondsSinceEpoch.toString(),
                                title: title,
                                amount: amount,
                                category: selectedCategory,
                                type: selectedType,
                                date: selectedDate,
                              ),
                            );
                          } else if (index != null) {
                            // Edit Operation
                            _transactions[index] = TransactionItem(
                              id: existingItem.id,
                              title: title,
                              amount: amount,
                              category: selectedCategory,
                              type: selectedType,
                              date: selectedDate,
                            );
                          }
                        });

                        _saveData();
                        Navigator.pop(ctx);
                      },
                      child: Text(
                        existingItem == null ? 'Add Transaction' : 'Save Changes',
                        style: const TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // Delete Operation
  void _deleteTransaction(int index) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Transaction'),
        content: const Text('Are you sure you want to delete this record?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              setState(() {
                _transactions.removeAt(index);
              });
              _saveData();
              Navigator.pop(ctx);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // Dialog to define monthly budget for categories (Post-Experiment Task 2)
  void _openBudgetDialog() {
    String budgetCat = _categories.first;
    final budgetController = TextEditingController(
      text: _categoryBudgets[budgetCat]?.toStringAsFixed(0) ?? '',
    );

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('Define Monthly Budget'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: budgetCat,
                  decoration: const InputDecoration(
                    labelText: 'Category',
                    border: OutlineInputBorder(),
                  ),
                  items: _categories.map((c) {
                    return DropdownMenuItem(value: c, child: Text(c));
                  }).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      setDialogState(() {
                        budgetCat = val;
                        budgetController.text =
                            _categoryBudgets[val]?.toStringAsFixed(0) ?? '';
                      });
                    }
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: budgetController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Monthly Limit (₹)',
                    prefixIcon: Icon(Icons.currency_rupee),
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  final limit = double.tryParse(budgetController.text.trim());
                  if (limit != null && limit >= 0) {
                    setState(() {
                      _categoryBudgets[budgetCat] = limit;
                    });
                    _saveData();
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('Save Budget'),
              ),
            ],
          );
        },
      ),
    );
  }

  // Icon for category
  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Food':
        return Icons.fastfood;
      case 'Transport':
        return Icons.directions_bus;
      case 'Bills':
        return Icons.receipt_long;
      case 'Entertainment':
        return Icons.movie;
      case 'Shopping':
        return Icons.shopping_bag;
      case 'Salary':
        return Icons.account_balance_wallet;
      default:
        return Icons.category;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Personal Expense Manager'),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Set Monthly Budgets',
            icon: const Icon(Icons.pie_chart_outline),
            onPressed: _openBudgetDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // 1. Summary Card (Income, Expense, Balance)
          Card(
            margin: const EdgeInsets.all(12),
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Net Balance',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                      Text(
                        '₹${_balance.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: _balance >= 0 ? Colors.indigo : Colors.red,
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      // Total Income
                      Column(
                        children: [
                          const Text('Total Income', style: TextStyle(color: Colors.grey)),
                          const SizedBox(height: 4),
                          Text(
                            '+₹${_totalIncome.toStringAsFixed(2)}',
                            style: const TextStyle(
                              color: Colors.green,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      Container(width: 1, height: 32, color: Colors.grey.shade300),
                      // Total Expenditure
                      Column(
                        children: [
                          const Text('Total Expense', style: TextStyle(color: Colors.grey)),
                          const SizedBox(height: 4),
                          Text(
                            '-₹${_totalExpense.toStringAsFixed(2)}',
                            style: const TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // 2. Category Budget Tracker (Post-Experiment Task 2)
          if (_categoryBudgets.isNotEmpty)
            Container(
              height: 72,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: _categoryBudgets.entries.map((entry) {
                  final cat = entry.key;
                  final budget = entry.value;
                  final spent = _getCategorySpent(cat);
                  final ratio = budget > 0 ? (spent / budget).clamp(0.0, 1.0) : 0.0;
                  final isExceeded = spent > budget;

                  return Container(
                    width: 155,
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isExceeded
                          ? Colors.red.shade50
                          : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isExceeded ? Colors.red : Colors.grey.shade300,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '$cat Budget',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '₹${spent.toStringAsFixed(0)} / ₹${budget.toStringAsFixed(0)}',
                          style: TextStyle(
                            fontSize: 11,
                            color: isExceeded ? Colors.red : Colors.black87,
                            fontWeight: isExceeded ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                        const SizedBox(height: 4),
                        LinearProgressIndicator(
                          value: ratio,
                          backgroundColor: Colors.grey.shade300,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            isExceeded ? Colors.red : Colors.indigo,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),

          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Transactions',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),

          // 3. Transactions List (ListView)
          Expanded(
            child: _transactions.isEmpty
                ? const Center(
                    child: Text(
                      'No transactions yet!\nTap + to add your first expense or income.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, fontSize: 14),
                    ),
                  )
                : ListView.builder(
                    itemCount: _transactions.length,
                    itemBuilder: (context, index) {
                      final item = _transactions[index];
                      final isIncome = item.type == 'Income';

                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        elevation: 1.5,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: isIncome
                                ? Colors.green.shade100
                                : Colors.red.shade100,
                            child: Icon(
                              _getCategoryIcon(item.category),
                              color: isIncome ? Colors.green.shade800 : Colors.red.shade800,
                            ),
                          ),
                          title: Text(
                            item.title,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            '${item.category} | ${item.date.day.toString().padLeft(2, '0')}/${item.date.month.toString().padLeft(2, '0')}/${item.date.year}',
                            style: const TextStyle(fontSize: 12),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '${isIncome ? '+' : '-'}₹${item.amount.toStringAsFixed(2)}',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: isIncome ? Colors.green : Colors.red,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.edit, size: 20, color: Colors.blue),
                                onPressed: () => _openTransactionForm(
                                  existingItem: item,
                                  index: index,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                                onPressed: () => _deleteTransaction(index),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openTransactionForm(),
        icon: const Icon(Icons.add),
        label: const Text('Add Entry'),
      ),
    );
  }
}
