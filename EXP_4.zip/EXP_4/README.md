# EXP_4: Personal Expense Manager

### Course Outcomes: CO1, CO3, CO5
A Flutter mobile application demonstrating state management using `StatefulWidget` and `setState()`, CRUD operations on dynamic lists, and local key-value persistence with `shared_preferences`.

---

## Features & Implementation

### 1. Requirements
- **Expense / Income Form**: Contains fields for `Amount`, `Category`, `Description`, and `Date` (via `showDatePicker`).
- **StatefulWidget & setState()**: UI dynamically reacts to state changes upon adding, modifying, or deleting transactions.
- **Display with ListView**: Uses `ListView.builder` with `Card` and `ListTile` displaying category avatar, title, date, and colored amount.
- **CRUD Operations**:
  - **Create**: Add new expense or income entries.
  - **Read**: View list of all transactions and summary calculations.
  - **Update**: Edit existing transactions by tapping the edit icon.
  - **Delete**: Remove transactions with confirmation dialog.
- **Expenditure & Summary**: Real-time calculation of total expenses.
- **Local Key-Value Storage**: Uses `shared_preferences` with `jsonEncode` and `jsonDecode` to persist transactions and budgets.
- **Automatic Loading**: Restores stored entries in `initState()` when the application starts.

---

## Post-Experiment Tasks (Implemented Choice 1 & 2)

### Task 1: Income Tracking & Balance Calculation
- Allows selecting entry type as **Expense** or **Income**.
- Calculates:
  - **Total Income**: Sum of all income transactions.
  - **Total Expense**: Sum of all expense transactions.
  - **Net Balance**: `Total Income - Total Expense`.
- Displayed prominently in a top overview card.

### Task 2: Monthly Category Budgets
- Allows users to define monthly budget limits for each category (via the top app bar action).
- Displays category budget status with spent amount, total budget, and a visual `LinearProgressIndicator`.
- Displays red warning alerts when spending exceeds the assigned category budget.

---

## Project Structure
```text
EXP_4/
├── lib/
│   ├── main.dart                     # App entry point with MaterialApp and Theme
│   ├── models/
│   │   └── transaction_model.dart    # TransactionItem data model with toMap/fromMap
│   └── screens/
│       └── expense_manager_screen.dart # Main screen with CRUD, budgets, summary & persistence
├── test/
│   └── widget_test.dart              # Basic widget smoke test
├── pubspec.yaml                     # Dependencies (flutter, shared_preferences, etc.)
└── README.md
```

---

## How to Run
```bash
flutter pub get
flutter run
```
