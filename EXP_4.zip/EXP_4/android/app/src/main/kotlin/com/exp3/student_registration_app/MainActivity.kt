package com.exp3.student_registration_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
