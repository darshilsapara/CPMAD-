import 'package:flutter/material.dart';
import 'registration_screen.dart';
import 'login_screen.dart';
import 'job_application_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF3F51B5), Color(0xFF5C6BC0), Color(0xFF7986CB)],
          ),
        ),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 32, 24, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'CPMAD • EXP 3',
                        style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 1.2),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Flutter Forms\n& Controls',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.w800,
                        height: 1.2,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Explore TextField, Radio, Checkbox,\nSwitch, Slider & Validation',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFFF5F6FF),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                  ),
                  child: ListView(
                    padding: const EdgeInsets.all(24),
                    children: [
                      const Text(
                        'Select a Module',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF2D3142),
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Tap any card to open the form',
                        style: TextStyle(color: Color(0xFF8B92B3), fontSize: 13),
                      ),
                      const SizedBox(height: 20),
                      _NavCard(
                        index: 0,
                        icon: Icons.person_add_rounded,
                        title: 'Student Registration',
                        subtitle: 'Name, Email, Phone, Password, Gender (Radio), Courses (Checkbox), Age (Slider), Preferences (Switch)',
                        tag: 'Main Experiment',
                        gradientColors: const [Color(0xFF5C6BC0), Color(0xFF3F51B5)],
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegistrationScreen())),
                      ),
                      const SizedBox(height: 16),
                      _NavCard(
                        index: 1,
                        icon: Icons.lock_rounded,
                        title: 'Login Screen',
                        subtitle: 'Email & Password validation with real-time error messages',
                        tag: 'Post-Exp Task 1',
                        gradientColors: const [Color(0xFF26A69A), Color(0xFF00897B)],
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
                      ),
                      const SizedBox(height: 16),
                      _NavCard(
                        index: 2,
                        icon: Icons.work_rounded,
                        title: 'Job Application',
                        subtitle: 'Personal info, Qualification, Skills (Checkbox), Experience (Slider)',
                        tag: 'Post-Exp Task 2',
                        gradientColors: const [Color(0xFFEF6C00), Color(0xFFE65100)],
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const JobApplicationScreen())),
                      ),
                      const SizedBox(height: 32),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEEF0FF),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFD0D4F0)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF5C6BC0).withOpacity(0.15),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.lightbulb_rounded, color: Color(0xFF5C6BC0), size: 22),
                            ),
                            const SizedBox(width: 14),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('CO3 Learning Objectives', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFF2D3142))),
                                  SizedBox(height: 4),
                                  Text('Forms • TextField • TextEditingController • Radio • Checkbox • Switch • Slider • Validation • State Management',
                                      style: TextStyle(color: Color(0xFF8B92B3), fontSize: 11, height: 1.5)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavCard extends StatelessWidget {
  final int index;
  final IconData icon;
  final String title;
  final String subtitle;
  final String tag;
  final List<Color> gradientColors;
  final VoidCallback onTap;

  const _NavCard({
    required this.index,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.tag,
    required this.gradientColors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradientColors,
          ),
          boxShadow: [
            BoxShadow(
              color: gradientColors.last.withOpacity(0.35),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(tag, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 0.8)),
                    ),
                    const SizedBox(height: 6),
                    Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12, height: 1.4)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 16),
            ],
          ),
        ),
      ),
    );
  }
}
