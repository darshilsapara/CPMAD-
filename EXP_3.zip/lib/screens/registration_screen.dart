import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'result_screen.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();

  // TextEditingControllers
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  // Radio – Gender
  String? _gender;

  // Checkboxes – Courses
  final Map<String, bool> _courses = {
    'Flutter Development': false,
    'Machine Learning': false,
    'Web Development': false,
    'Cyber Security': false,
    'Cloud Computing': false,
    'Data Science': false,
  };

  // Slider – Age
  double _age = 18;

  // Switches – Preferences
  bool _newsletter = false;
  bool _notifications = true;
  bool _termsAccepted = false;

  bool _obscurePassword = true;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  List<String> get _selectedCourses =>
      _courses.entries.where((e) => e.value).map((e) => e.key).toList();

  void _submit() {
    // Validate checkbox group separately
    if (_selectedCourses.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(children: [
            Icon(Icons.warning_amber_rounded, color: Colors.white),
            SizedBox(width: 8),
            Text('Please select at least one course'),
          ]),
          backgroundColor: Colors.orange.shade700,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    if (!_termsAccepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(children: [
            Icon(Icons.warning_amber_rounded, color: Colors.white),
            SizedBox(width: 8),
            Text('Please accept Terms & Conditions'),
          ]),
          backgroundColor: Colors.orange.shade700,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    if (_formKey.currentState!.validate()) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(data: {
            'Name': _nameCtrl.text.trim(),
            'Email': _emailCtrl.text.trim(),
            'Phone': _phoneCtrl.text.trim(),
            'Gender': _gender ?? 'Not specified',
            'Age': '${_age.round()} years',
            'Courses': _selectedCourses.join(', '),
            'Newsletter': _newsletter ? 'Subscribed' : 'Not subscribed',
            'Notifications': _notifications ? 'Enabled' : 'Disabled',
          }),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FF),
      appBar: AppBar(
        title: const Text('Student Registration'),
        backgroundColor: const Color(0xFF3F51B5),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _SectionHeader(icon: Icons.person_rounded, title: 'Personal Information'),
            const SizedBox(height: 12),

            // Name
            TextFormField(
              controller: _nameCtrl,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Full Name',
                prefixIcon: Icon(Icons.person_outline_rounded, color: Color(0xFF5C6BC0)),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Name is required';
                if (v.trim().length < 3) return 'Name must be at least 3 characters';
                if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(v.trim())) return 'Name should contain only letters';
                return null;
              },
            ),
            const SizedBox(height: 14),

            // Email
            TextFormField(
              controller: _emailCtrl,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'Email Address',
                prefixIcon: Icon(Icons.email_outlined, color: Color(0xFF5C6BC0)),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Email is required';
                if (!RegExp(r'^[\w.+\-]+@[a-zA-Z\d\-]+\.[a-zA-Z]+$').hasMatch(v.trim())) {
                  return 'Enter a valid email address';
                }
                return null;
              },
            ),
            const SizedBox(height: 14),

            // Phone
            TextFormField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              maxLength: 10,
              decoration: const InputDecoration(
                labelText: 'Phone Number',
                prefixIcon: Icon(Icons.phone_outlined, color: Color(0xFF5C6BC0)),
                counterText: '',
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'Phone number is required';
                if (v.length != 10) return 'Enter a valid 10-digit phone number';
                return null;
              },
            ),
            const SizedBox(height: 14),

            // Password
            TextFormField(
              controller: _passwordCtrl,
              obscureText: _obscurePassword,
              decoration: InputDecoration(
                labelText: 'Password',
                prefixIcon: const Icon(Icons.lock_outline_rounded, color: Color(0xFF5C6BC0)),
                suffixIcon: IconButton(
                  icon: Icon(_obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined, color: const Color(0xFF8B92B3)),
                  onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                ),
              ),
              validator: (v) {
                if (v == null || v.isEmpty) return 'Password is required';
                if (v.length < 8) return 'Password must be at least 8 characters';
                if (!RegExp(r'(?=.*[A-Z])').hasMatch(v)) return 'Must contain an uppercase letter';
                if (!RegExp(r'(?=.*\d)').hasMatch(v)) return 'Must contain a number';
                return null;
              },
            ),
            const SizedBox(height: 24),

            // Gender
            _SectionHeader(icon: Icons.wc_rounded, title: 'Gender Selection'),
            const SizedBox(height: 12),
            _SectionCard(
              child: Column(
                children: ['Male', 'Female', 'Prefer not to say'].map((g) {
                  return RadioListTile<String>(
                    value: g,
                    groupValue: _gender,
                    title: Text(g, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                    activeColor: const Color(0xFF5C6BC0),
                    contentPadding: EdgeInsets.zero,
                    visualDensity: VisualDensity.compact,
                    onChanged: (v) => setState(() => _gender = v),
                  );
                }).toList(),
              ),
            ),
            if (_gender == null && _formKey.currentState != null)
              const Padding(
                padding: EdgeInsets.only(left: 12, top: 4),
                child: Text('Please select a gender', style: TextStyle(color: Color(0xFFEF5350), fontSize: 12)),
              ),
            const SizedBox(height: 24),

            // Courses
            _SectionHeader(icon: Icons.school_rounded, title: 'Course / Skill Selection'),
            const SizedBox(height: 12),
            _SectionCard(
              child: Column(
                children: _courses.entries.map((entry) {
                  return CheckboxListTile(
                    value: entry.value,
                    title: Text(entry.key, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                    activeColor: const Color(0xFF5C6BC0),
                    contentPadding: EdgeInsets.zero,
                    visualDensity: VisualDensity.compact,
                    controlAffinity: ListTileControlAffinity.leading,
                    onChanged: (v) => setState(() => _courses[entry.key] = v!),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),

            // Age Slider
            _SectionHeader(icon: Icons.cake_rounded, title: 'Age Selection'),
            const SizedBox(height: 12),
            _SectionCard(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Age', style: TextStyle(color: Color(0xFF8B92B3), fontSize: 13)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFF5C6BC0),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text('${_age.round()} yrs',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                      ),
                    ],
                  ),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: const Color(0xFF5C6BC0),
                      inactiveTrackColor: const Color(0xFFD0D4F0),
                      thumbColor: const Color(0xFF3F51B5),
                      overlayColor: const Color(0xFF5C6BC0).withOpacity(0.12),
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
                      trackHeight: 6,
                    ),
                    child: Slider(
                      value: _age,
                      min: 16,
                      max: 60,
                      divisions: 44,
                      onChanged: (v) => setState(() => _age = v),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('16', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                      Text('60', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Preferences Switches
            _SectionHeader(icon: Icons.tune_rounded, title: 'Additional Preferences'),
            const SizedBox(height: 12),
            _SectionCard(
              child: Column(
                children: [
                  _SwitchTile(
                    icon: Icons.email_rounded,
                    title: 'Newsletter Subscription',
                    subtitle: 'Receive updates & news',
                    value: _newsletter,
                    onChanged: (v) => setState(() => _newsletter = v),
                  ),
                  const Divider(height: 24),
                  _SwitchTile(
                    icon: Icons.notifications_rounded,
                    title: 'Push Notifications',
                    subtitle: 'Get alerts on your device',
                    value: _notifications,
                    onChanged: (v) => setState(() => _notifications = v),
                  ),
                  const Divider(height: 24),
                  _SwitchTile(
                    icon: Icons.verified_user_rounded,
                    title: 'Terms & Conditions',
                    subtitle: 'I accept the terms of service',
                    value: _termsAccepted,
                    onChanged: (v) => setState(() => _termsAccepted = v),
                    activeColor: const Color(0xFF26A69A),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Submit Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _submit,
                icon: const Icon(Icons.check_circle_outline_rounded),
                label: const Text('Submit Registration'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  backgroundColor: const Color(0xFF3F51B5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// ── Reusable Widgets ──────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  const _SectionHeader({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFF5C6BC0).withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: const Color(0xFF5C6BC0), size: 18),
        ),
        const SizedBox(width: 10),
        Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFF2D3142))),
      ],
    );
  }
}

class _SectionCard extends StatelessWidget {
  final Widget child;
  const _SectionCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFDDE1F0)),
        boxShadow: [
          BoxShadow(color: const Color(0xFF5C6BC0).withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 4)),
        ],
      ),
      child: child,
    );
  }
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color activeColor;

  const _SwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    this.activeColor = const Color(0xFF5C6BC0),
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: activeColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: activeColor, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
              Text(subtitle, style: const TextStyle(fontSize: 11, color: Color(0xFF8B92B3))),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: activeColor,
        ),
      ],
    );
  }
}
