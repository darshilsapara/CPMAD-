import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'result_screen.dart';

/// Post-Experiment Task 2: Job Application Form
class JobApplicationScreen extends StatefulWidget {
  const JobApplicationScreen({super.key});

  @override
  State<JobApplicationScreen> createState() => _JobApplicationScreenState();
}

class _JobApplicationScreenState extends State<JobApplicationScreen> {
  final _formKey = GlobalKey<FormState>();
  int _currentStep = 0;

  // ── Personal Information ──────────────────────────────────────────────────
  final _firstNameCtrl = TextEditingController();
  final _lastNameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  String? _gender;

  // ── Qualification ─────────────────────────────────────────────────────────
  String? _qualification;
  final _institutionCtrl = TextEditingController();
  final _yearCtrl = TextEditingController();
  String? _grade;

  // ── Skills ────────────────────────────────────────────────────────────────
  final Map<String, bool> _technicalSkills = {
    'Flutter / Dart': false,
    'React / JavaScript': false,
    'Python': false,
    'Java': false,
    'SQL / Databases': false,
    'Node.js': false,
    'Machine Learning': false,
    'DevOps / Docker': false,
  };
  final Map<String, bool> _softSkills = {
    'Leadership': false,
    'Communication': false,
    'Problem Solving': false,
    'Teamwork': false,
  };

  // ── Experience ────────────────────────────────────────────────────────────
  double _experience = 0;
  String? _jobType;
  final _coverCtrl = TextEditingController();
  bool _relocate = false;
  bool _remoteOk = true;

  @override
  void dispose() {
    _firstNameCtrl.dispose();
    _lastNameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _institutionCtrl.dispose();
    _yearCtrl.dispose();
    _coverCtrl.dispose();
    super.dispose();
  }

  List<String> get _selectedTech => _technicalSkills.entries.where((e) => e.value).map((e) => e.key).toList();
  List<String> get _selectedSoft => _softSkills.entries.where((e) => e.value).map((e) => e.key).toList();

  bool _validateStep(int step) {
    switch (step) {
      case 0:
        return _firstNameCtrl.text.trim().isNotEmpty &&
            _lastNameCtrl.text.trim().isNotEmpty &&
            _emailCtrl.text.trim().isNotEmpty &&
            RegExp(r'^[\w.+\-]+@[a-zA-Z\d\-]+\.[a-zA-Z]+$').hasMatch(_emailCtrl.text.trim()) &&
            _phoneCtrl.text.trim().length == 10 &&
            _gender != null;
      case 1:
        return _qualification != null && _institutionCtrl.text.trim().isNotEmpty && _yearCtrl.text.trim().isNotEmpty;
      case 2:
        return _selectedTech.isNotEmpty;
      case 3:
        return _jobType != null;
      default:
        return false;
    }
  }

  void _next() {
    if (!_validateStep(_currentStep)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(children: [
            Icon(Icons.warning_amber_rounded, color: Colors.white),
            SizedBox(width: 8),
            Text('Please fill all required fields'),
          ]),
          backgroundColor: Colors.orange.shade700,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }
    if (_currentStep < 3) {
      setState(() => _currentStep++);
    } else {
      _submit();
    }
  }

  void _submit() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(data: {
          'Full Name': '${_firstNameCtrl.text.trim()} ${_lastNameCtrl.text.trim()}',
          'Email': _emailCtrl.text.trim(),
          'Phone': _phoneCtrl.text.trim(),
          'Gender': _gender ?? '',
          'Qualification': _qualification ?? '',
          'Institution': _institutionCtrl.text.trim(),
          'Passing Year': _yearCtrl.text.trim(),
          'Grade': _grade ?? 'Not specified',
          'Technical Skills': _selectedTech.join(', '),
          'Soft Skills': _selectedSoft.isNotEmpty ? _selectedSoft.join(', ') : 'None selected',
          'Experience': '${_experience.toStringAsFixed(1)} years',
          'Job Type': _jobType ?? '',
          'Willing to Relocate': _relocate ? 'Yes' : 'No',
          'Open to Remote': _remoteOk ? 'Yes' : 'No',
        }),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F5),
      appBar: AppBar(
        title: const Text('Job Application'),
        backgroundColor: const Color(0xFFE65100),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          // Step indicator
          Container(
            color: const Color(0xFFE65100),
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              children: [
                Row(
                  children: List.generate(4, (i) {
                    final labels = ['Personal', 'Education', 'Skills', 'Experience'];
                    final isActive = i == _currentStep;
                    final isDone = i < _currentStep;
                    return Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    color: isDone
                                        ? Colors.white
                                        : isActive
                                            ? Colors.white
                                            : Colors.white.withOpacity(0.3),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Center(
                                    child: isDone
                                        ? const Icon(Icons.check_rounded, color: Color(0xFFE65100), size: 16)
                                        : Text(
                                            '${i + 1}',
                                            style: TextStyle(
                                              color: isActive ? const Color(0xFFE65100) : Colors.white70,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 13,
                                            ),
                                          ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(labels[i],
                                    style: TextStyle(
                                      color: isActive ? Colors.white : Colors.white60,
                                      fontSize: 10,
                                      fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                                    )),
                              ],
                            ),
                          ),
                          if (i < 3)
                            Expanded(
                              child: Container(
                                height: 2,
                                margin: const EdgeInsets.only(bottom: 20),
                                color: i < _currentStep ? Colors.white : Colors.white.withOpacity(0.3),
                              ),
                            ),
                        ],
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),

          Expanded(
            child: Form(
              key: _formKey,
              child: IndexedStack(
                index: _currentStep,
                children: [
                  _buildPersonalInfo(),
                  _buildQualification(),
                  _buildSkills(),
                  _buildExperience(),
                ],
              ),
            ),
          ),

          // Navigation buttons
          Container(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Colors.grey.shade200)),
            ),
            child: Row(
              children: [
                if (_currentStep > 0)
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => setState(() => _currentStep--),
                      icon: const Icon(Icons.arrow_back_rounded, size: 18),
                      label: const Text('Back'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        foregroundColor: const Color(0xFFE65100),
                        side: const BorderSide(color: Color(0xFFE65100)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                if (_currentStep > 0) const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton.icon(
                    onPressed: _next,
                    icon: Icon(_currentStep == 3 ? Icons.send_rounded : Icons.arrow_forward_rounded, size: 18),
                    label: Text(_currentStep == 3 ? 'Submit Application' : 'Next'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE65100),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── Step 0: Personal Info ────────────────────────────────────────────────
  Widget _buildPersonalInfo() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _StepTitle(title: 'Personal Information', subtitle: 'Tell us about yourself'),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _firstNameCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'First Name *'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextFormField(
                controller: _lastNameCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Last Name *'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _emailCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
            labelText: 'Email Address *',
            prefixIcon: Icon(Icons.email_outlined, color: Color(0xFFEF6C00)),
          ),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          maxLength: 10,
          decoration: const InputDecoration(
            labelText: 'Phone Number *',
            prefixIcon: Icon(Icons.phone_outlined, color: Color(0xFFEF6C00)),
            counterText: '',
          ),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _addressCtrl,
          maxLines: 2,
          decoration: const InputDecoration(
            labelText: 'Address',
            prefixIcon: Icon(Icons.location_on_outlined, color: Color(0xFFEF6C00)),
          ),
        ),
        const SizedBox(height: 20),
        const Text('Gender *', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            children: ['Male', 'Female', 'Non-binary', 'Prefer not to say'].map((g) {
              return RadioListTile<String>(
                value: g,
                groupValue: _gender,
                title: Text(g, style: const TextStyle(fontSize: 14)),
                activeColor: const Color(0xFFEF6C00),
                visualDensity: VisualDensity.compact,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                onChanged: (v) => setState(() => _gender = v),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  // ─── Step 1: Qualification ────────────────────────────────────────────────
  Widget _buildQualification() {
    final qualifications = ['10th / SSC', '12th / HSC', 'Diploma', "Bachelor's Degree", "Master's Degree", 'PhD'];
    final grades = ['A+', 'A', 'B+', 'B', 'C'];

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _StepTitle(title: 'Qualification', subtitle: 'Your educational background'),
        const SizedBox(height: 20),

        const Text('Highest Qualification *',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            children: qualifications.map((q) {
              return RadioListTile<String>(
                value: q,
                groupValue: _qualification,
                title: Text(q, style: const TextStyle(fontSize: 14)),
                activeColor: const Color(0xFFEF6C00),
                visualDensity: VisualDensity.compact,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                onChanged: (v) => setState(() => _qualification = v),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _institutionCtrl,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Institution / University *',
            prefixIcon: Icon(Icons.school_outlined, color: Color(0xFFEF6C00)),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _yearCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                maxLength: 4,
                decoration: const InputDecoration(
                  labelText: 'Passing Year *',
                  counterText: '',
                  prefixIcon: Icon(Icons.calendar_today_rounded, color: Color(0xFFEF6C00)),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: _grade,
                decoration: const InputDecoration(labelText: 'Grade'),
                items: grades.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                onChanged: (v) => setState(() => _grade = v),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ─── Step 2: Skills ───────────────────────────────────────────────────────
  Widget _buildSkills() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _StepTitle(title: 'Skills', subtitle: 'Select your technical & soft skills'),
        const SizedBox(height: 20),

        const Text('Technical Skills *',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            children: _technicalSkills.entries.map((entry) {
              return CheckboxListTile(
                value: entry.value,
                title: Text(entry.key, style: const TextStyle(fontSize: 14)),
                activeColor: const Color(0xFFEF6C00),
                visualDensity: VisualDensity.compact,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                controlAffinity: ListTileControlAffinity.leading,
                onChanged: (v) => setState(() => _technicalSkills[entry.key] = v!),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 20),

        const Text('Soft Skills',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            children: _softSkills.entries.map((entry) {
              return CheckboxListTile(
                value: entry.value,
                title: Text(entry.key, style: const TextStyle(fontSize: 14)),
                activeColor: const Color(0xFFEF6C00),
                visualDensity: VisualDensity.compact,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                controlAffinity: ListTileControlAffinity.leading,
                onChanged: (v) => setState(() => _softSkills[entry.key] = v!),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  // ─── Step 3: Experience ───────────────────────────────────────────────────
  Widget _buildExperience() {
    final jobTypes = ['Full-Time', 'Part-Time', 'Internship', 'Contract', 'Freelance'];

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _StepTitle(title: 'Experience & Preferences', subtitle: 'Work experience and job preferences'),
        const SizedBox(height: 20),

        // Experience Slider
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Years of Experience', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEF6C00),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _experience == 0 ? 'Fresher' : '${_experience.toStringAsFixed(1)} yrs',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                ],
              ),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: const Color(0xFFEF6C00),
                  inactiveTrackColor: const Color(0xFFFFDDC4),
                  thumbColor: const Color(0xFFE65100),
                  overlayColor: const Color(0xFFEF6C00).withOpacity(0.12),
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
                  trackHeight: 6,
                ),
                child: Slider(
                  value: _experience,
                  min: 0,
                  max: 20,
                  divisions: 40,
                  onChanged: (v) => setState(() => _experience = v),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Fresher', style: TextStyle(color: Colors.grey.shade500, fontSize: 11)),
                  Text('20 yrs', style: TextStyle(color: Colors.grey.shade500, fontSize: 11)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        const Text('Job Type *',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142))),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            children: jobTypes.map((t) {
              return RadioListTile<String>(
                value: t,
                groupValue: _jobType,
                title: Text(t, style: const TextStyle(fontSize: 14)),
                activeColor: const Color(0xFFEF6C00),
                visualDensity: VisualDensity.compact,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                onChanged: (v) => setState(() => _jobType = v),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 20),

        // Preferences
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFDDE1F0)),
          ),
          child: Column(
            children: [
              _SwitchRow(
                label: 'Willing to Relocate',
                value: _relocate,
                onChanged: (v) => setState(() => _relocate = v),
                color: const Color(0xFFEF6C00),
              ),
              const Divider(height: 20),
              _SwitchRow(
                label: 'Open to Remote Work',
                value: _remoteOk,
                onChanged: (v) => setState(() => _remoteOk = v),
                color: const Color(0xFFEF6C00),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        TextFormField(
          controller: _coverCtrl,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Cover Letter (Optional)',
            alignLabelWithHint: true,
            prefixIcon: Padding(
              padding: EdgeInsets.only(bottom: 60),
              child: Icon(Icons.article_outlined, color: Color(0xFFEF6C00)),
            ),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}

// ── Shared Widgets ────────────────────────────────────────────────────────────

class _StepTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const _StepTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFF2D3142))),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Color(0xFF8B92B3), fontSize: 13)),
      ],
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color color;

  const _SwitchRow({
    required this.label,
    required this.value,
    required this.onChanged,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF2D3142)))),
        Switch(value: value, onChanged: onChanged, activeColor: color),
      ],
    );
  }
}
